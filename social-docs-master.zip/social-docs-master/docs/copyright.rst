Copyrights and Licence
======================

``python-social-auth`` is protected by BSD licence. Check the LICENCE_ for
details.

The base work was derived from django-social-auth_ work and copyrighted too,
check `django-social-auth LICENCE`_ for details:

.. _LICENCE: https://github.com/python-social-auth/social-core/blob/master/LICENSE
.. _django-social-auth: https://github.com/omab/django-social-auth
.. _django-social-auth LICENCE: https://github.com/omab/django-social-auth/blob/master/LICENSE
