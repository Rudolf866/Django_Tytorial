SUSE
====

This section describes how to setup the different services provided by SUSE and openSUSE.


openSUSE OpenID
---------------

openSUSE OpenID works straightforward, not settings are needed. Domains or emails
whitelists can be applied too, check the whitelists_ settings for details.

.. _whitelists: ../configuration/settings.html#whitelists
