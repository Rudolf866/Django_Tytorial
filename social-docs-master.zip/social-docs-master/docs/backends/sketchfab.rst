Sketchfab
=========

Sketchfab uses OAuth 2 for authentication.

To use:

- Follow the steps at `Sketchfab Oauth`_, and ask for an
  ``Authorization code`` grant type.

- Fill the ``Client id/key`` and ``Client Secret`` values you received
  in your django settings::

      SOCIAL_AUTH_SKETCHFAB_KEY   = ''
      SOCIAL_AUTH_SKETCHFAB_SECRET = ''

.. _Sketchfab Oauth: https://sketchfab.com/developers/oauth
