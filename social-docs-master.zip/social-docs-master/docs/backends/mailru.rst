Mail.ru OAuth
=============

Mail.ru uses OAuth2 workflow, to use it fill in settings::

    SOCIAL_AUTH_MAILRU_OAUTH2_KEY = ''
    SOCIAL_AUTH_MAILRU_OAUTH2_SECRET = ''
