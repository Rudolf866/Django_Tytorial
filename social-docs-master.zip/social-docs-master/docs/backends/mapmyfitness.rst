MapMyFitness
============

MapMyFitness uses OAuth v2 for authentication.

- Register a new application at the `MapMyFitness API`_, and

- fill ``key`` and ``secret`` values in the settings::

      SOCIAL_AUTH_MAPMYFITNESS_KEY = ''
      SOCIAL_AUTH_MAPMYFITNESS_SECRET = ''

.. _MapMyFitness API: https://www.mapmyapi.com
