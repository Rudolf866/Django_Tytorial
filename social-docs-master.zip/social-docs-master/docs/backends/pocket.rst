Pocket
======

Pocket uses a weird variant of OAuth v2 that only defines a consumer key.

- Register a new application at the `Pocket API`_, and

- fill ``consumer key`` value in the settings::

      SOCIAL_AUTH_POCKET_KEY = ''

.. _Pocket API: http://getpocket.com/developer/
