Withings
========

Withings uses OAuth v1 for Authentication.

- Register a new application at the `Withings API`_, and

- fill ``Client ID`` and ``Client Secret`` from withings.com values in the settings::

      SOCIAL_AUTH_WITHINGS_KEY = ''
      SOCIAL_AUTH_WITHINGS_SECRET = ''

.. _Withings API: https://oauth.withings.com/partner/add
