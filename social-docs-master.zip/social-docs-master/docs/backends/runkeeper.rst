RunKeeper
=========

RunKeeper uses OAuth v2 for authentication.

- Register a new application at the `RunKeeper API`_, and

- fill ``Client Id`` and ``Client Secret`` values in the settings::

      SOCIAL_AUTH_RUNKEEPER_KEY = ''
      SOCIAL_AUTH_RUNKEEPER_SECRET = ''

.. _RunKeeper API: http://developer.runkeeper.com/healthgraph
