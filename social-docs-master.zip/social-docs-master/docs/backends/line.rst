Line.me
=======

Fill App Id and Secret in your project settings::

	SOCIAL_AUTH_LINE_KEY = '...'
	SOCIAL_AUTH_LINE_SECRET = '...'
