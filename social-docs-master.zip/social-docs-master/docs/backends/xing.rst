XING
====

XING uses OAuth1 for their auth mechanism, in order to enable the backend
follow:

- Register a new application at `XING Apps Dashboard`_,

- Fill **Consumer Key** and **Consumer Secret** values::

      SOCIAL_AUTH_XING_KEY = ''
      SOCIAL_AUTH_XING_SECRET = ''

.. _XING Apps Dashboard: https://dev.xing.com/applications
