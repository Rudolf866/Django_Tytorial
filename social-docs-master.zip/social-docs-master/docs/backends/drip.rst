Drip
====

Drip uses OAuth v2 for Authentication.

- Register a new application with `Drip`_, and

- fill ``Client ID`` and ``Client Secret`` from getdrip.com values in
  the settings::

      SOCIAL_AUTH_DRIP_KEY = ''
      SOCIAL_AUTH_DRIP_SECRET = ''

.. _Drip: https://www.getdrip.com/user/applications
