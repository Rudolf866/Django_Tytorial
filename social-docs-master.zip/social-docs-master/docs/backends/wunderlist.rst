Wunderlist
==========

Wunderlist uses OAuth v2 for Authentication.

- Register a new application at `Wunderlist Developer Portal`_, and

- fill ``Client Id`` and ``Client Secret`` values in the settings::

      SOCIAL_AUTH_WUNDERLIST_KEY = ''
      SOCIAL_AUTH_WUNDERLIST_SECRET = ''

.. _Wunderlist Developer Portal: https://developer.wunderlist.com/applications
