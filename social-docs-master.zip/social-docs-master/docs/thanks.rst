Thanks
======


python-social-auth_ is the result of almost 3 years of development done on
django-social-auth_ which is the result of my initial work and the thousands
lines of code contributed by so many developers that took time to work on
improvements, report bugs and hunt them down to propose a fix. So, here is
a big list of users that helped to build this library (if somebody is missed
let me know and I'll update the list):

  * kjoconnor_
  * krvss_
  * estebistec_
  * mrmch_
  * uruz_
  * maraujop_
  * bacher09_
  * dokterbob_
  * hassek_
  * andrusha_
  * vicalloy_
  * caioariede_
  * danielgtaylor_
  * stephenmcd_
  * gugu_
  * yrik_
  * dhendo_
  * yekibud_
  * tmackenzie_
  * LuanP_
  * jezdez_
  * serdardalgic_
  * Jolmberg_
  * ChrisCooper_
  * marselester_
  * eshellman_
  * micrypt_
  * revolunet_
  * dasevilla_
  * seansay_
  * hepochen_
  * gibuloto_
  * crodjer_
  * sidmitra_
  * ryr_
  * inve1_
  * mback2k_
  * hannesstruss_
  * NorthIsUp_
  * tonyxiao_
  * dhepper_
  * Troytft_
  * gardaud_
  * oinopion_
  * gameguy43_
  * vinigracindo_
  * syabro_
  * bashmish_
  * ggreer_
  * avillavi_
  * r4vi_
  * roderyc_
  * daonb_
  * slon7_
  * JasonGiedymin_
  * tymofij_
  * Cassus_
  * martey_
  * t0m_
  * johnthedebs_
  * jammons_
  * stefanw_
  * maxgrosse_
  * mattucf_
  * tadeo_
  * haxoza_
  * bradbeattie_
  * henward0_
  * bernardokyotoku_
  * czpython_
  * glasscube42_
  * assiotis_
  * dbaxa_
  * JasonSanford_
  * originell_
  * cihann_
  * niftynei_
  * mikesun_
  * 1st_
  * betonimig_
  * ozexpert_
  * stephenLee_
  * julianvargasalvarez_
  * youngrok_
  * garrypolley_
  * amirouche_
  * fmoga_
  * pydanny_
  * pygeek_
  * dgouldin_
  * kotslon_
  * kirkchris_
  * barracel_
  * sayar_
  * kulbir_
  * Morgul_
  * spstpl_
  * bluszcz_
  * vbsteven_
  * sbassi_
  * aspcanada_
  * browniebroke_


.. _python-social-auth: https://github.com/python-social-auth
.. _django-social-auth: https://github.com/omab/django-social-auth
.. _kjoconnor: https://github.com/kjoconnor
.. _krvss: https://github.com/krvss
.. _estebistec: https://github.com/estebistec
.. _mrmch: https://github.com/mrmch
.. _uruz: https://github.com/uruz
.. _maraujop: https://github.com/maraujop
.. _bacher09: https://github.com/bacher09
.. _dokterbob: https://github.com/dokterbob
.. _hassek: https://github.com/hassek
.. _andrusha: https://github.com/andrusha
.. _vicalloy: https://github.com/vicalloy
.. _caioariede: https://github.com/caioariede
.. _danielgtaylor: https://github.com/danielgtaylor
.. _stephenmcd: https://github.com/stephenmcd
.. _gugu: https://github.com/gugu
.. _yrik: https://github.com/yrik
.. _dhendo: https://github.com/dhendo
.. _yekibud: https://github.com/yekibud
.. _tmackenzie: https://github.com/tmackenzie
.. _LuanP: https://github.com/LuanP
.. _jezdez: https://github.com/jezdez
.. _serdardalgic: https://github.com/serdardalgic
.. _Jolmberg: https://github.com/Jolmberg
.. _ChrisCooper: https://github.com/ChrisCooper
.. _marselester: https://github.com/marselester
.. _eshellman: https://github.com/eshellman
.. _micrypt: https://github.com/micrypt
.. _revolunet: https://github.com/revolunet
.. _dasevilla: https://github.com/dasevilla
.. _seansay: https://github.com/seansay
.. _hepochen: https://github.com/hepochen
.. _gibuloto: https://github.com/gibuloto
.. _crodjer: https://github.com/crodjer
.. _sidmitra: https://github.com/sidmitra
.. _ryr: https://github.com/ryr
.. _inve1: https://github.com/inve1
.. _mback2k: https://github.com/mback2k
.. _hannesstruss: https://github.com/hannesstruss
.. _NorthIsUp: https://github.com/NorthIsUp
.. _tonyxiao: https://github.com/tonyxiao
.. _dhepper: https://github.com/dhepper
.. _Troytft: https://github.com/Troytft
.. _gardaud: https://github.com/gardaud
.. _oinopion: https://github.com/oinopion
.. _gameguy43: https://github.com/gameguy43
.. _vinigracindo: https://github.com/vinigracindo
.. _syabro: https://github.com/syabro
.. _bashmish: https://github.com/bashmish
.. _ggreer: https://github.com/ggreer
.. _avillavi: https://github.com/avillavi
.. _r4vi: https://github.com/r4vi
.. _roderyc: https://github.com/roderyc
.. _daonb: https://github.com/daonb
.. _slon7: https://github.com/slon7
.. _JasonGiedymin: https://github.com/JasonGiedymin
.. _tymofij: https://github.com/tymofij
.. _Cassus: https://github.com/Cassus
.. _martey: https://github.com/martey
.. _t0m: https://github.com/t0m
.. _johnthedebs: https://github.com/johnthedebs
.. _jammons: https://github.com/jammons
.. _stefanw: https://github.com/stefanw
.. _maxgrosse: https://github.com/maxgrosse
.. _mattucf: https://github.com/mattucf
.. _tadeo: https://github.com/tadeo
.. _haxoza: https://github.com/haxoza
.. _bradbeattie: https://github.com/bradbeattie
.. _henward0: https://github.com/henward0
.. _bernardokyotoku: https://github.com/bernardokyotoku
.. _czpython: https://github.com/czpython
.. _glasscube42: https://github.com/glasscube42
.. _assiotis: https://github.com/assiotis
.. _dbaxa: https://github.com/dbaxa
.. _JasonSanford: https://github.com/JasonSanford
.. _originell: https://github.com/originell
.. _cihann: https://github.com/cihann
.. _niftynei: https://github.com/niftynei
.. _mikesun: https://github.com/mikesun
.. _1st: https://github.com/1st
.. _betonimig: https://github.com/betonimig
.. _ozexpert: https://github.com/ozexpert
.. _stephenLee: https://github.com/stephenLee
.. _julianvargasalvarez: https://github.com/julianvargasalvarez
.. _youngrok: https://github.com/youngrok
.. _garrypolley: https://github.com/garrypolley
.. _amirouche: https://github.com/amirouche
.. _fmoga: https://github.com/fmoga
.. _pydanny: https://github.com/pydanny
.. _pygeek: https://github.com/pygeek
.. _dgouldin: https://github.com/dgouldin
.. _kotslon: https://github.com/kotslon
.. _kirkchris: https://github.com/kirkchris
.. _barracel: https://github.com/barracel
.. _sayar: https://github.com/sayar
.. _kulbir: https://github.com/kulbir
.. _Morgul: https://github.com/Morgul
.. _spstpl: https://github.com/spstpl
.. _bluszcz: https://github.com/bluszcz
.. _vbsteven: https://github.com/vbsteven
.. _sbassi: https://github.com/sbassi
.. _aspcanada: https://github.com/aspcanada
.. _browniebroke: https://github.com/browniebroke
