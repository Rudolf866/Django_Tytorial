from example.models import user
from social_flask_sqlalchemy import models
