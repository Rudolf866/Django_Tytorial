from example.models import user
from social_flask_peewee import models
